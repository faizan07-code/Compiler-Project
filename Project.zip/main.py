import re

KEYWORDS = {
    'loop', 'agar', 'magar', 'asm', 'else', 'new', 'this', 'auto', 'enum', 'operator', 'throw', 'bool', 'explicit',
    'private', 'true', 'break', 'export', 'protected', 'try', 'case', 'extern', 'public', 'typedef', 'catch', 'false',
    'register', 'typeid', 'char', 'float', 'typename', 'class', 'for', 'return', 'union', 'const', 'friend', 'short',
    'unsigned', 'goto', 'signed', 'using', 'continue', 'if', 'sizeof', 'virtual', 'default', 'inline', 'static', 'void',
    'delete', 'int', 'volatile', 'do', 'long', 'struct', 'double', 'mutable', 'switch', 'while', 'namespace',
    'def', 'return', 'class', 'import', 'try', 'except', 'finally', 'global', 'lambda', 'assert', 'with', 'elif'
}

PATTERNS = {
    'identifier': r'^[a-zA-Z_][a-zA-Z0-9_]*$', 
    'number': r'^[+-]?\d+(\.\d+)?([eE][+-]?\d+)?|\d+[eE][+-]?\d+$',
    'operator': r'!=|<>|=:=|==|\+|\-|\*|\/|>>|<<|\+\+|--|\+=|\-=|&&|\|\||=>|=<|%|:|::|<|>|=|!',
    'punctuation': r'[{}(),;."#<>\[\]""'']', 
    'keyword': r'\b(?:' + '|'.join(KEYWORDS) + r')\b',
}

def tokenize_file(file_path):
    with open(file_path, 'r') as file:
        content = file.read()
    tokens = re.findall(r'[\w]+|[^\w\s]', content)
    return tokens

def classify_tokens(tokens):
    counts = {
        'total': len(tokens),
        'valid': 0,
        'invalid': 0,
        'identifier': 0,
        'number': 0,
        'operator': 0,
        'punctuation': 0,
        'keyword': 0
    }
    invalid_tokens = []

    for token in tokens:
        if re.match(PATTERNS['keyword'], token):
            counts['keyword'] += 1
            counts['valid'] += 1
        elif re.match(PATTERNS['identifier'], token):
            if token not in KEYWORDS:
                counts['identifier'] += 1
                counts['valid'] += 1
            else:
                counts['invalid'] += 1
                invalid_tokens.append(token)
        elif re.match(PATTERNS['number'], token):
            counts['number'] += 1
            counts['valid'] += 1
        elif re.match(PATTERNS['operator'], token):
            counts['operator'] += 1
            counts['valid'] += 1
        elif re.match(PATTERNS['punctuation'], token):
            counts['punctuation'] += 1
            counts['valid'] += 1
        else:
            invalid_tokens.append(token)
            counts['invalid'] += 1

    return counts, invalid_tokens

def write_report(file_path, output_file):
    tokens = tokenize_file(file_path)
    counts, invalid_tokens = classify_tokens(tokens)

    with open(output_file, 'w') as output:
        output.write(f"Total tokens: {counts['total']}\n")
        output.write("\nValid tokens:\n")
        output.write(f"  identifier: {counts['identifier']}\n")
        output.write(f"  number: {counts['number']}\n")
        output.write(f"  operator: {counts['operator']}\n")
        output.write(f"  punctuation: {counts['punctuation']}\n")
        output.write(f"  keyword: {counts['keyword']}\n")
        output.write(f"\nTotal valid tokens: {counts['valid']}\n")
        output.write(f"\nInvalid tokens: {counts['invalid']}\n")
        if invalid_tokens:
            output.write("  Invalid tokens:\n")
            for token in invalid_tokens:
                output.write(f"    {token}\n")

source_file = 'source.txt'  
output_file = 'output.txt'  
write_report(source_file, output_file)
